//
//  main.m
//  Web Browser
//
//  Created by Jesse Yaverbaum on 3/14/17.
//  Copyright © 2017 Jesse Yaverbaum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
